# Banking with Axon 4.3.4 & Spring Boot 2.3.1
Banking with Axon 4.3.4 & Spring Boot 2.3.1

## Environment Variables
```
ENVIRONMENT_UNMSM = dev
MYSQL_UNMSM_BANKING_AXON_URL = jdbc:mysql://{HOST}:{PORT}/{DATABASE_NAME}?verifyServerCertificate=false&useSSL=false&useTimezone=true&serverTimezone=UTC
MYSQL_UNMSM_BANKING_AXON_USER = {USERNAME}
MYSQL_UNMSM_BANKING_AXON_PASSWORD = {PASSWORD}
```
