package pe.edu.unmsm.banking.transfers.messages.events;

public class MoneyTransferCompletedEvent(
	val transactionId: String
)

public class MoneyTransferFailedEvent(
	val transactionId: String
)

public class MoneyTransferRequestedEvent(
	val transactionId: String,
	val sourceAccountId: String,
	val destinationAccountId: String,
	val amount: Double
)
