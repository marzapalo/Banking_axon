package pe.edu.unmsm.banking.customers.messages.commands;

import org.axonframework.modelling.command.TargetAggregateIdentifier
import javax.persistence.Column

public class EditCustomerCommand (
	@TargetAggregateIdentifier
/*	@Column(length = 36)*/
	val customerId: String,
	val firstName: String,
	val lastName: String,
	val identityDocumentNumber: String
)
public class RegisterCustomerCommand (
	@TargetAggregateIdentifier
	val customerId: String,
	val firstName: String,
	val lastName: String,
	val identityDocumentNumber: String
)
