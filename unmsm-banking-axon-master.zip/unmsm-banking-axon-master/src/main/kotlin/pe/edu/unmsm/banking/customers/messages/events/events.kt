package pe.edu.unmsm.banking.customers.messages.events

public class CustomerEditedEvent(
	val customerId: String,
	/*val date_update: Date,*/
	val firstName: String,
	val identityDocumentNumber: String,
	val lastName: String
	/*val status:String*/

)


public class CustomerRegisteredEvent(
	val customerId: String,
	val firstName: String,
	val lastName: String,
	val identityDocumentNumber: String
)
