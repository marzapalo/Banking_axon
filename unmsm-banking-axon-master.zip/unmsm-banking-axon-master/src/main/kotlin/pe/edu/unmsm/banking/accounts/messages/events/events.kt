package pe.edu.unmsm.banking.accounts.messages.events

abstract class BalanceUpdatedEvent(
	val accountId: String,
	val balance: Double
)

class MoneyDepositedEvent(
	accountId: String,
	val transactionId : String,
	val amount: Double,
	balance: Double) : BalanceUpdatedEvent(accountId, balance)

class MoneyWithdrawnEvent(
	accountId: String,
	val transactionId : String,
	val amount: Double,
	balance: Double) : BalanceUpdatedEvent(accountId, balance)

public class AccountEditedEvent(
	val accountId: String,
	val overdraftLimit: Double
)

public class AccountOpenedEvent(
	val accountId: String,
	val overdraftLimit: Double,
	val customerId: String
)

public class DestinationAccountCreditedEvent(
	val accountId: String,
	val amount: Double,
	val transactionId: String
)

public class DestinationAccountNotFoundEvent(
	val accountId: String,
	val transactionId: String
)

public class MoneyOfFailedMoneyTransferReturnedEvent(
	val accountId: String,
	val amount: Double,
	val transactionId: String
)

public class SourceAccountDebitedEvent(
	val accountId: String,
	val amount: Double,
	val transactionId: String
)

public class SourceAccountDebitRejectedEvent(
	val accountId: String,
	val transactionId: String
)

public class SourceAccountNotFoundEvent(
	val accountId: String,
	val transactionId: String
)
