package pe.edu.unmsm.banking.transfers.messages.commands;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

public class MarkMoneyTransferCompletedCommand(
	@TargetAggregateIdentifier
	val transactionId: String
)

public class MarkMoneyTransferFailedCommand(

	@TargetAggregateIdentifier
	val transactionId: String

)

public class RequestMoneyTransferCommand(
	@TargetAggregateIdentifier
	val transactionId: String,
	val sourceAccountId: String,
	val destinationAccountId: String,
	val amount: Double
)