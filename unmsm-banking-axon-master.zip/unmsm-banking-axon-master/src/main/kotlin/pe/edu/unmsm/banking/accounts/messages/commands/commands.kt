package pe.edu.unmsm.banking.accounts.messages.commands;

import org.axonframework.modelling.command.TargetAggregateIdentifier
import javax.persistence.Column

class DepositMoneyCommand(
	@TargetAggregateIdentifier val accountId: String,
	val transactionId : String,
	val amount: Double
)

class WithdrawMoneyCommand(
	@TargetAggregateIdentifier val accountId: String,
	val transactionId : String,
	val amount: Double
)

public class CreditDestinationAccountCommand(
	@TargetAggregateIdentifier	val accountId: String,
	val transferId: String,
	val amount: Double
)

public class DebitSourceAccountCommand(
	@TargetAggregateIdentifier
	val accountId: String,
	val transferId: String,
	val amount: Double
)

public class EditAccountCommand(
	@TargetAggregateIdentifier
	val accountId: String,
	val overdraftLimit: Double
)

public class OpenAccountCommand(
	@TargetAggregateIdentifier
	@Column(length = 36)
	val accountId: String,
	val overdraftLimit: Double,
	val customerId: String
)

public class ReturnMoneyOfFailedMoneyTransferCommand(
	@TargetAggregateIdentifier
	val accountId: String,
	val transferId: String,
	val amount: Double
)

