package pe.edu.unmsm.banking.accounts.query;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import pe.edu.unmsm.banking.accounts.messages.events.AccountEditedEvent;
import pe.edu.unmsm.banking.accounts.messages.events.AccountOpenedEvent;
import pe.edu.unmsm.banking.accounts.messages.events.DestinationAccountCreditedEvent;
import pe.edu.unmsm.banking.accounts.messages.events.MoneyDepositedEvent;
import pe.edu.unmsm.banking.accounts.messages.events.MoneyWithdrawnEvent;
import pe.edu.unmsm.banking.accounts.messages.events.SourceAccountDebitedEvent;

@Component
public class AccountLogViewProjection {
	private final AccountLogViewRepository AccountLogViewRepository;
	
	public AccountLogViewProjection(AccountLogViewRepository AccountLogViewRepository) {
        this.AccountLogViewRepository = AccountLogViewRepository;
    }
	
	@EventHandler
    public void on(AccountOpenedEvent event) {
		AccountLogView AccountLogView = new AccountLogView(event.getAccountId(), event.getCustomerId(), 0.0, event.getOverdraftLimit());
		AccountLogViewRepository.save(new AccountLogView(AccountLogView));
    }
	
	@EventHandler
    public void on(AccountEditedEvent event) {
		AccountLogView AccountLogView = AccountLogViewRepository.findLast(event.getAccountId());	
		AccountLogView = new AccountLogView(AccountLogView);
		AccountLogView.setOverdraftLimit(event.getOverdraftLimit());
		AccountLogViewRepository.save(AccountLogView);
    }
	
	@EventHandler
    public void on(MoneyDepositedEvent event) {
		AccountLogView AccountLogView = AccountLogViewRepository.findLast(event.getAccountId());
		AccountLogView = new AccountLogView(AccountLogView);
		AccountLogView.setBalance(AccountLogView.getBalance() + event.getAmount());
		AccountLogViewRepository.save(AccountLogView);
    }
	
	@EventHandler
    public void on(MoneyWithdrawnEvent event) {
		AccountLogView AccountLogView = AccountLogViewRepository.findLast(event.getAccountId());
		AccountLogView = new AccountLogView(AccountLogView);
		AccountLogView.setBalance(AccountLogView.getBalance() - event.getAmount());
		AccountLogViewRepository.save(AccountLogView);
    }
	
	@EventHandler
    public void on(SourceAccountDebitedEvent event) {
		AccountLogView AccountLogView = AccountLogViewRepository.findLast(event.getAccountId());
		AccountLogView = new AccountLogView(AccountLogView);
		AccountLogView.setBalance(AccountLogView.getBalance() - event.getAmount());
		AccountLogViewRepository.save(AccountLogView);
    }
	
	@EventHandler
    public void on(DestinationAccountCreditedEvent event) {
		AccountLogView AccountLogView = AccountLogViewRepository.findLast(event.getAccountId());
		AccountLogView = new AccountLogView(AccountLogView);
		AccountLogView.setBalance(AccountLogView.getBalance() + event.getAmount());
		AccountLogViewRepository.save(AccountLogView);
    }
}