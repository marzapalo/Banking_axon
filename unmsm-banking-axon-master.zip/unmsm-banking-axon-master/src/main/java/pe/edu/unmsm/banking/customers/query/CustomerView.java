package pe.edu.unmsm.banking.customers.query;

import javax.persistence.*;
import java.util.Date;

@Entity
public class CustomerView {
	@Id
	@Column(length=36)
    private String customerId;
	private String firstName;
	private String lastName;
	private String identityDocumentNumber;
	private String status;
	/*insertar nuevo campo fecha*/
	private Date dateUpdate;
	
	public CustomerView() {
	}

	public CustomerView(String customerId, String firstName, String lastName, String identityDocumentNumber, String status) {
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.identityDocumentNumber = identityDocumentNumber;
		this.status = status;
		/*se agrega al constructor*/
		this.dateUpdate = new Date();

    }

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Date getDateUpdate() {
		return dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIdentityDocumentNumber() {
		return identityDocumentNumber;
	}

	public void setIdentityDocumentNumber(String identityDocumentNumber) {
		this.identityDocumentNumber = identityDocumentNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}