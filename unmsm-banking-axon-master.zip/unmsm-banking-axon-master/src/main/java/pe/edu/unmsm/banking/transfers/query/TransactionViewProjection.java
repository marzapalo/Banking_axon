package pe.edu.unmsm.banking.transfers.query;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import pe.edu.unmsm.banking.transfers.domain.TransactionType;
import pe.edu.unmsm.banking.accounts.messages.events.DestinationAccountCreditedEvent;
import pe.edu.unmsm.banking.accounts.messages.events.MoneyDepositedEvent;
import pe.edu.unmsm.banking.accounts.messages.events.MoneyWithdrawnEvent;
import pe.edu.unmsm.banking.accounts.messages.events.SourceAccountDebitedEvent;

@Component
public class TransactionViewProjection {
	private final TransactionViewRepository transactionViewRepository;
	
	public TransactionViewProjection(TransactionViewRepository transactionViewRepository) {
        this.transactionViewRepository = transactionViewRepository;
    }
	
	@EventHandler
    public void on(MoneyDepositedEvent event) {
		String transactionId = event.getTransactionId();
		String accountId = event.getAccountId();
		double amount = event.getAmount();
	    String transactionType = TransactionType.DEPOSIT.toString();
		
		TransactionView transactionView = new TransactionView(transactionId, accountId, amount, transactionType);
		transactionViewRepository.save(transactionView);
    }
	
	@EventHandler
    public void on(MoneyWithdrawnEvent event) {
		String transactionId = event.getTransactionId();
		String accountId = event.getAccountId();
		double amount = event.getAmount();
	    String transactionType = TransactionType.WITHDRAW.toString();
	    TransactionView transactionView = new TransactionView(transactionId, accountId, amount, transactionType);
		transactionViewRepository.save(transactionView);
    }
	
	@EventHandler
    public void on(SourceAccountDebitedEvent event) {
		String transactionId = event.getTransactionId();
		String accountId = event.getAccountId();
		double amount = event.getAmount();
	    String transactionType = TransactionType.TRANSFER_WITHDRAW.toString();
	    TransactionView transactionView = new TransactionView(transactionId, accountId, amount, transactionType);
		transactionViewRepository.save(transactionView);
    }
	
	@EventHandler
    public void on(DestinationAccountCreditedEvent event) {
		String transactionId = event.getTransactionId();
		String accountId = event.getAccountId();
		double amount = event.getAmount();
	    String transactionType = TransactionType.TRANSFER_DEPOSIT.toString();
	    TransactionView transactionView = new TransactionView(transactionId, accountId, amount, transactionType);
		transactionViewRepository.save(transactionView);
    }
}