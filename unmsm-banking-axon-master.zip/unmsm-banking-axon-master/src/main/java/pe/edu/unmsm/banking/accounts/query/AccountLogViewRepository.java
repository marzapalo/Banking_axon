package pe.edu.unmsm.banking.accounts.query;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountLogViewRepository extends JpaRepository<AccountLogView, String> {
	AccountLogView findOneByAccountId(String accountId);
	AccountLogView findLast(String accountId);
}