package pe.edu.unmsm.banking.transfers.domain;

public enum TransactionType {
	DEPOSIT, WITHDRAW, TRANSFER_DEPOSIT, TRANSFER_WITHDRAW
}
