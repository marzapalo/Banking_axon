package pe.edu.unmsm.banking.accounts.domain

class OverdraftLimitExceededException() : Exception()