package pe.edu.unmsm.banking.transfers.query;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionViewRepository extends JpaRepository<TransactionView, String> {
	List<TransactionView> findListByAccountId(String accountId);
}