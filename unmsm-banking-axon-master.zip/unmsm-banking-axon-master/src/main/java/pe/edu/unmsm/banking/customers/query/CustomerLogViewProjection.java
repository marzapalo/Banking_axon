package pe.edu.unmsm.banking.customers.query;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import pe.edu.unmsm.banking.customers.messages.events.CustomerEditedEvent;
import pe.edu.unmsm.banking.customers.messages.events.CustomerRegisteredEvent;

@Component
public class CustomerLogViewProjection {
    private final CustomerLogViewRepository CustomerLogViewRepository;

    public CustomerLogViewProjection(CustomerLogViewRepository CustomerLogViewRepository) {
        this.CustomerLogViewRepository = CustomerLogViewRepository;
    }

    @EventHandler
    public void on(CustomerRegisteredEvent event) {
        CustomerLogView CustomerLogView = new  CustomerLogView(event.getCustomerId(), event.getFirstName(), event.getLastName(), event.getIdentityDocumentNumber());
        CustomerLogViewRepository.save(new CustomerLogView(CustomerLogView));
    }

    @EventHandler
    public void on(CustomerEditedEvent event) {
        CustomerLogView CustomerLogView = CustomerLogViewRepository.findLast(event.getCustomerId());
        CustomerLogView = new CustomerLogView(CustomerLogView);
        CustomerLogView.setFirstName(event.getFirstName());
        CustomerLogView.setLastName(event.getLastName());
        CustomerLogView.setIdentityDocumentNumber(event.getIdentityDocumentNumber());
       /* CustomerLogView.setDateUpdate(event.getDate_update());
        CustomerLogView.setStatus(event.getStatus());*/

        CustomerLogViewRepository.save(CustomerLogView);
    }

}
