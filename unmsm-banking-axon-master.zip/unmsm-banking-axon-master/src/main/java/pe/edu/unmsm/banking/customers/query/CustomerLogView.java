package pe.edu.unmsm.banking.customers.query;

import pe.edu.unmsm.banking.accounts.query.AccountLogView;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import java.util.Date;


@Entity
@NamedQuery(name="CustomerLogView.findLast", query="select d " +
        "from CustomerLogView d " +
        "where d.logId = (select max(d.logId) from CustomerLogView d where d.customerId = : customerId)")

public class CustomerLogView {
    @Id
    @GeneratedValue
    private long logId;
    @Column(length=36)
    private String customerId;

    private String firstName;
    private String lastName;
    private String identityDocumentNumber;

    public CustomerLogView() {
    }
    public CustomerLogView(CustomerLogView CustomerLogView) {
        this.customerId = CustomerLogView.customerId;
        this.firstName = CustomerLogView.firstName;
        this.lastName = CustomerLogView.lastName;
        this.identityDocumentNumber = CustomerLogView.identityDocumentNumber;

    }

    public CustomerLogView(String customerId, String firstName, String lastName, String identityDocumentNumber/*, String status/*, double overdraftLimit*/) {
        this.customerId = customerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.identityDocumentNumber = identityDocumentNumber;

    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getIdentityDocumentNumber() {
        return identityDocumentNumber;
    }

    public void setIdentityDocumentNumber(String identityDocumentNumber) {
        this.identityDocumentNumber = identityDocumentNumber;
    }

    public long getLogId() {
        return logId;
    }
    public void setLogId(long logId) {
        this.logId = logId;
    }
}
