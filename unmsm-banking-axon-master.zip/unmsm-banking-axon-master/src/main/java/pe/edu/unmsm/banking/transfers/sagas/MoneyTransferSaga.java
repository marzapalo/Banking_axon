package pe.edu.unmsm.banking.transfers.sagas;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.modelling.saga.EndSaga;
import org.axonframework.modelling.saga.SagaEventHandler;
import org.axonframework.modelling.saga.StartSaga;
import org.axonframework.spring.stereotype.Saga;

import pe.edu.unmsm.banking.accounts.messages.commands.CreditDestinationAccountCommand;
import pe.edu.unmsm.banking.accounts.messages.commands.DebitSourceAccountCommand;
import pe.edu.unmsm.banking.accounts.messages.commands.ReturnMoneyOfFailedMoneyTransferCommand;
import pe.edu.unmsm.banking.accounts.messages.events.DestinationAccountCreditedEvent;
import pe.edu.unmsm.banking.accounts.messages.events.DestinationAccountNotFoundEvent;
import pe.edu.unmsm.banking.accounts.messages.events.SourceAccountDebitRejectedEvent;
import pe.edu.unmsm.banking.accounts.messages.events.SourceAccountDebitedEvent;
import pe.edu.unmsm.banking.accounts.messages.events.SourceAccountNotFoundEvent;
import pe.edu.unmsm.banking.transfers.messages.commands.MarkMoneyTransferCompletedCommand;
import pe.edu.unmsm.banking.transfers.messages.commands.MarkMoneyTransferFailedCommand;
import pe.edu.unmsm.banking.transfers.messages.events.MoneyTransferRequestedEvent;

import javax.inject.Inject;

@Saga
public class MoneyTransferSaga {
	private String sourceAccountId;
    private String destinationAccountId;
    private double amount;
    
	@Inject
    private transient CommandGateway commandGateway;
	
	@StartSaga
    @SagaEventHandler(associationProperty = "transactionId")
    public void on(MoneyTransferRequestedEvent event) {
		this.sourceAccountId = event.getSourceAccountId();
        this.destinationAccountId = event.getDestinationAccountId();
        this.amount = event.getAmount();
        DebitSourceAccountCommand command = new DebitSourceAccountCommand(
        		event.getSourceAccountId(),
                event.getTransactionId(),
                event.getAmount());
        commandGateway.send(command);
	}
	
	@SagaEventHandler(associationProperty = "transactionId")
    @EndSaga
    public void on(SourceAccountNotFoundEvent event) {
        MarkMoneyTransferFailedCommand command = new MarkMoneyTransferFailedCommand(event.getTransactionId());
        commandGateway.send(command);
    }
	
	@SagaEventHandler(associationProperty = "transactionId")
    @EndSaga
    public void on(DestinationAccountNotFoundEvent event) {
        ReturnMoneyOfFailedMoneyTransferCommand returnMoneyCommand = 
        		new ReturnMoneyOfFailedMoneyTransferCommand(this.sourceAccountId, event.getTransactionId(), this.amount);
        commandGateway.send(returnMoneyCommand);

        MarkMoneyTransferFailedCommand command = new MarkMoneyTransferFailedCommand(
                event.getTransactionId());
        commandGateway.send(command);
    }
	
	@SagaEventHandler(associationProperty = "transactionId")
    @EndSaga
    public void on(SourceAccountDebitRejectedEvent event) {
		MarkMoneyTransferFailedCommand command = new MarkMoneyTransferFailedCommand(event.getTransactionId());
		commandGateway.send(command);
    }
	
	@SagaEventHandler(associationProperty = "transactionId")
    public void on(SourceAccountDebitedEvent event) {
        CreditDestinationAccountCommand command = 
        		new CreditDestinationAccountCommand(destinationAccountId,
                                                    event.getTransactionId(),
                                                    event.getAmount());
        commandGateway.send(command);
    }
	
	@EndSaga
    @SagaEventHandler(associationProperty = "transactionId")
    public void on(DestinationAccountCreditedEvent event) {
        MarkMoneyTransferCompletedCommand command = new MarkMoneyTransferCompletedCommand(event.getTransactionId());
        commandGateway.send(command);
    }
}