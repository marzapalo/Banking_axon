package pe.edu.unmsm.banking.customers.domain;

public enum CustomerStatus {
	ACTIVE,
    INACTIVE
}