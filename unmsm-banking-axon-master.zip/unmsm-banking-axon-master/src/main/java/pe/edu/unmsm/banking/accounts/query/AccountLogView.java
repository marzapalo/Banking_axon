package pe.edu.unmsm.banking.accounts.query;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity

@NamedQuery(name="AccountLogView.findLast", query="select d " + 
		"from AccountLogView d " + 
		"where d.logId = (select max(d.logId) from AccountLogView d where d.accountId = : accountId)") 
public class AccountLogView {
	@Id
	@GeneratedValue
	private Long logId;
	@Column(length=36)
    private String accountId;
    private String customerId;
    private double balance;

	private double overdraftLimit;
	
	private Date dateInsert;

    public AccountLogView() {
    }
    
    public AccountLogView(AccountLogView accountLogView) {
        this.accountId = accountLogView.accountId;
        this.customerId = accountLogView.customerId;
        this.balance = accountLogView.balance;
        this.overdraftLimit = accountLogView.overdraftLimit;
        this.dateInsert = new Date();
    }
    
    public AccountLogView(String accountId, String customerId, double balance, double overdraftLimit) {
        this.accountId = accountId;
        this.customerId = customerId;
        this.balance = balance;
        this.overdraftLimit = overdraftLimit;
        this.dateInsert = new Date();
    }

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}	

    public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getOverdraftLimit() {
		return overdraftLimit;
	}

	public void setOverdraftLimit(double overdraftLimit) {
		this.overdraftLimit = overdraftLimit;
	}

	public Long getLogId() {
		return logId;
	}

	public void setLogId(Long logId) {
		this.logId = logId;
	}

	public Date getDateInsert() {
		return dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}
}